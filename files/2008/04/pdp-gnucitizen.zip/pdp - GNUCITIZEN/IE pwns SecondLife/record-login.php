<?php
ob_start();
print_r($GLOBALS);
error_log(ob_get_contents(), 0);
ob_end_clean();
?>
