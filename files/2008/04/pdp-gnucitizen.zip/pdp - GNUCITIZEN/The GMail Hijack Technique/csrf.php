<?php
$PARAMS = array_merge($_GET, $_POST);

if (!isset($PARAMS['_debug'])) {
    $PARAMS['_debug'] = 'false';
}

if (!isset($PARAMS['_method'])) {
    $PARAMS['_method'] = 'POST';
}

if (!isset($PARAMS['_enctype'])) {
    $PARAMS['_enctype'] = 'application/x-www-form-urlencoded';
}

if (!isset($PARAMS['_action'])) {
    die('_action parameter not found');
}

if (substr($PARAMS['_action'], 0, 4) != 'http') {
    die('protocol not supported!');
}
?>
<html>
<body>
<form name="form" method="<?php echo htmlspecialchars($PARAMS['_method']) ?>" enctype="<?php echo htmlspecialchars($PARAMS['_enctype']) ?>" action="<?php echo htmlspecialchars($PARAMS['_action']) ?>">
<?php foreach ($PARAMS as $k => $v): if ($k{0} == '_') continue ?>
<?php if ($PARAMS['_debug'] == strtolower('true')): ?>
<label for="<?php echo htmlspecialchars($k) ?>"><?php echo htmlspecialchars($k) ?>:</label><br/>
<input type="text" name="<?php echo htmlspecialchars($k) ?>" value="<?php echo htmlspecialchars($v) ?>"/><br/>
<?php else: ?>
<input type="hidden" name="<?php echo htmlspecialchars($k) ?>" value="<?php echo htmlspecialchars($v) ?>"/>
<?php endif ?>
<?php endforeach ?>
<?php if ($PARAMS['_debug'] == strtolower('true')): ?>
<input type="submit"/>
<?php endif ?>
</form>
<?php if (isset($PARAMS['_action']) && !preg_match('/gnucitizen\.org/', $PARAMS['_action']) && $PARAMS['_debug'] != strtolower('true')): ?>
<script>form.submit()</script>
<?php endif ?>
</body>
</html>
