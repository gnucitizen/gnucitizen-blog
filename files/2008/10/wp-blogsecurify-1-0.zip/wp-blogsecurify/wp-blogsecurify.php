<?php
/**
 * Plugin Name: WP Blogsecurify
 * Plugin URI: http://www.blogsecurify.com
 * Description: secures your wordpress blog
 * Author: Petko D. (pdp) Petkov
 * Author URI: http://www.pdp.io
 * Version: 1.0
 */

	/**
	 * FORCE HTTPS ON WP_BLOGSECURIFY_IS_AUTHENTICATED, ADMIN_COOKIE_PATH and COOKIEPATH
	 */
		function wp_blogsecurify_force_https() {
			if (!is_ssl() && ($_COOKIE['wp_blogsecurify_is_authenticated'] == 'true' || preg_match('#^/*(?:'.ADMIN_COOKIE_PATH.'|'.SITECOOKIEPATH.'/*wp-login\.php)#', $_SERVER['REQUEST_URI']))) {
				header('Location: https://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);

				exit;
			}
		}

		add_action('init', 'wp_blogsecurify_force_https', 1);

	/**
	 * FORCE HTTPS ON HTTPS AND WP_BLOGSECURIFY_IS_AUTHENTICATED,
	 */
		function wp_blogsecurify_force_https_url($url) {
			if (is_ssl() || ($_COOKIE['wp_blogsecurify_is_authenticated'] == 'true')) {
				$url = preg_replace('#^https?://#', 'https://', $url, 1);
			}

			return $url;
		}

		add_filter('bloginfo_url', 'wp_blogsecurify_force_https_url', 10);
		add_filter('option_url', 'wp_blogsecurify_force_https_url', 10);
		add_filter('option_home', 'wp_blogsecurify_force_https_url', 10);
		add_filter('option_wpurl', 'wp_blogsecurify_force_https_url', 10);
		add_filter('option_siteurl', 'wp_blogsecurify_force_https_url', 10);
		add_filter('option_template_url', 'wp_blogsecurify_force_https_url', 10);

	/**
	 * FORCE SECURE HTTPONLY COOKIES
	 */
		if (!function_exists('wp_set_auth_cookie')) {
			function wp_set_auth_cookie($user_id, $remember = false, $secure = '') {
				if ($remember) {
					$expiration = $expire = time() + 1209600;
				} else {
					$expiration = time() + 172800;
					$expire = 0;
				}

				if ('' === $secure) {
					$secure = is_ssl() ? true : false;
				}

				if ($secure) {
					$auth_cookie_name = SECURE_AUTH_COOKIE;
					$scheme = 'secure_auth';
				} else {
					$auth_cookie_name = AUTH_COOKIE;
					$scheme = 'auth';
				}

				$auth_cookie = wp_generate_auth_cookie($user_id, $expiration, $scheme);
				$logged_in_cookie = wp_generate_auth_cookie($user_id, $expiration, 'logged_in');

				do_action('set_auth_cookie', $auth_cookie, $expire, $expiration, $user_id, $scheme);
				do_action('set_logged_in_cookie', $logged_in_cookie, $expire, $expiration, $user_id, 'logged_in');

				setcookie($auth_cookie_name, $auth_cookie, $expire, PLUGINS_COOKIE_PATH, COOKIE_DOMAIN, true, true);
				setcookie($auth_cookie_name, $auth_cookie, $expire, ADMIN_COOKIE_PATH, COOKIE_DOMAIN, true, true);
				setcookie(LOGGED_IN_COOKIE, $logged_in_cookie, $expire, COOKIEPATH, COOKIE_DOMAIN, true, true);

				if (COOKIEPATH != SITECOOKIEPATH) {
					setcookie(LOGGED_IN_COOKIE, $logged_in_cookie, $expire, SITECOOKIEPATH, COOKIE_DOMAIN, true, true);
				}
			}
		}

	/**
	 * IDENTIFY AUTHENTICATED USERS SECURELY
	 */
		function wp_blogsecurify_wp_logout() {
			setcookie('wp_blogsecurify_is_authenticated', ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
			setcookie('wp_blogsecurify_is_authenticated', ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);
		}

		function wp_blogsecurify_set_auth_cookie($auth_cookie, $expire, $expiration, $user_id, $scheme) {
			setcookie('wp_blogsecurify_is_authenticated', 'true', $expire, COOKIEPATH, COOKIE_DOMAIN, false, true);
			setcookie('wp_blogsecurify_is_authenticated', 'true', $expire, SITECOOKIEPATH, COOKIE_DOMAIN, false, true);
		}

		add_action('wp_logout', 'wp_blogsecurify_wp_logout', 10);
		add_action('set_auth_cookie', 'wp_blogsecurify_set_auth_cookie', 10, 5);

	/**
	 * HIDE DATABASE ERRORS
	 */
		function wp_blogsecurify_hide_database_errors() {
			global $wpdb;

			$wpdb->show_errors = false;
		}

		add_action('init', 'wp_blogsecurify_hide_database_errors', 1);
		add_action('parse_query', 'wp_blogsecurify_hide_database_errors', 1);

	/*
	 * INSTALL DASHBOARD WIDGET
	 */
		function wp_blogsecurify_register_dashboard_widget() {
			wp_register_sidebar_widget('dashboard_wp_blogsecurify', __('WP Blogsecurify', 'wp_blogsecurify'), 'dashboard_wp_blogsecurify',
				array(
					'width' => 'half',
					'height' => 'double',
				)
			);
		}

		add_action('wp_dashboard_setup', 'wp_blogsecurify_register_dashboard_widget');
 
		function wp_blogsecurify_add_dashboard_widget($widgets) {
			global $wp_registered_widgets;

			if (!isset($wp_registered_widgets['dashboard_wp_blogsecurify'])) {
				return $widgets;
			}

			array_splice($widgets, 0, 0, 'dashboard_wp_blogsecurify');

			return $widgets;
		}

		add_filter('wp_dashboard_widgets', 'wp_blogsecurify_add_dashboard_widget');

		include_once(ABSPATH.WPINC.'/rss.php');
 
		function dashboard_wp_blogsecurify($sidebar_args) {
			global $wpdb;

			extract($sidebar_args, EXTR_SKIP);

			echo $before_widget;
			echo $before_title;
			echo $widget_name;
			echo $after_title;

			?>
				<div style="font-size:300%;text-transform:uppercase">Status:ON</div>
				<p>WP Blogsecurify is a security plugin for Wordpress designed to integrate several simple but important security patches for the popular blogging platform. This plugin was developed by the <a href="http://www.blogsecurify.com">Blogsecurify</a> team - a special division of <a href="http://www.gnucitizen.org">GNUCITIZEN</a> Information Security Think Tank.</p>
				<p>WP Blogsecurify protects your blog by:</p>
				<ul>
					<li style="margin:0">forcing users to login over a secure communication channel.</li>
					<li style="margin:0">protecting session identifiers from incidental session leaks.</li>
					<li style="margin:0">hiding database errors which could be caused by malfunctioning plugins.</li>
					<li style="margin:0">protecting the entire user session from session-hijacking attacks.</li>
				</ul>
				<p><em>This plugin is designed to be simple and effective. Future versions will protect against SQLI and XSS attacks. We are also planning to integrate WP Blogsecurify with our free social media security testing engine.</em></p>

				<h3>Blogsecurify Special Feed <em><a href="http://www.blogsecurify.com/advertise">(&raquo; more)</a></em></h3>
			<?php

			$rss = fetch_rss('http://www.adsosimple.com/advertisement?channel=f2217062e9a397a1dca429e7d70bc6ca&output=rss');
			$rss_items = array_slice($rss->items, 0, 5);

			if (sizeof($rss_items) > 0) {
				echo '<ul>';

				foreach ($rss_items as $item) {
					echo '<li>'.$item['description'].'</li>';
				}

				echo '</ul>';
			}

			?>
				<h3>Information Security Gigs Feed <em><a href="http://www.gnucitizen.net/gigs">(&raquo; more)</a></em></h3>
			<?php

			$rss = fetch_rss('http://www.adsosimple.com/advertisement?channel=9683cc5f89562ea48e72bb321d9f03fb&output=rss');
			$rss_items = array_slice($rss->items, 0, 5);

			if (sizeof($rss_items) > 0) {
				echo '<ul>';

				foreach ($rss_items as $item) {
					echo '<li>'.$item['description'].'</li>';
				}

				echo '</ul>';
			}

			echo $after_widget;
		}
